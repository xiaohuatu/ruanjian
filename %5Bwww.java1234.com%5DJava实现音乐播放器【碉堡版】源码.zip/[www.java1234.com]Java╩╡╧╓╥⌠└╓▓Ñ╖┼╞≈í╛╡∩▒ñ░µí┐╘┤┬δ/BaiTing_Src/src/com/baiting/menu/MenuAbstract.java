package com.baiting.menu;

import javax.swing.JMenu;

public abstract class MenuAbstract {

	public abstract JMenu close();
	
	public abstract JMenu minWindow();
	
	public abstract JMenu maxWindow();
	
	public abstract JMenu reWindow();
	
}
