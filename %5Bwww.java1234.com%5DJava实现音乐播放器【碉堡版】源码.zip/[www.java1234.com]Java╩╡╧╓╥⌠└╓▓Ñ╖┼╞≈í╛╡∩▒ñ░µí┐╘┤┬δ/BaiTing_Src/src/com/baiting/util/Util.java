package com.baiting.util;

import java.util.logging.Logger;

public class Util {
	protected static final Logger log = Logger.getLogger(Util.class.getName());
	
}
