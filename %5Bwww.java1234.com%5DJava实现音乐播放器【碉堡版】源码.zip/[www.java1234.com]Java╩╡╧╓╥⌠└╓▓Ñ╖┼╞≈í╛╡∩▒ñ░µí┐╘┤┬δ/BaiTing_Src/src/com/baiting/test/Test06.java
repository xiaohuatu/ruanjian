package com.baiting.test;

public class Test06 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ThreadTest01 test = ThreadTest01.getInstance();
		test.setState(1);
	}

}
