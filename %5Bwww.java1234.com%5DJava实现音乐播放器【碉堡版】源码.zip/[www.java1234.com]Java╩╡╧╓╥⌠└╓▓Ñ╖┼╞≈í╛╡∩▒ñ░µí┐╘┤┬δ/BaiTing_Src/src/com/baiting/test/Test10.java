package com.baiting.test;


public class Test10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
	}

}
