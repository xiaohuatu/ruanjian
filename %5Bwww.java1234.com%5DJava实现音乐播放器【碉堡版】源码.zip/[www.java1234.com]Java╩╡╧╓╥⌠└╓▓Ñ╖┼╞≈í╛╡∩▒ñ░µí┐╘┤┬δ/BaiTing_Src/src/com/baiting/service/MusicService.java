package com.baiting.service;

import java.util.logging.Logger;

import com.baiting.Music;

public class MusicService extends Music {
	
	protected final static Logger log = Logger.getLogger(MusicService.class.getName());
	
}
