package com.baiting.layout;

import javax.swing.JLabel;
import javax.swing.table.DefaultTableCellRenderer;

public class MTableCellRenderer extends DefaultTableCellRenderer {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6815078435874977228L;

	public MTableCellRenderer () {
		setHorizontalAlignment(JLabel.CENTER);
	}
	
}
