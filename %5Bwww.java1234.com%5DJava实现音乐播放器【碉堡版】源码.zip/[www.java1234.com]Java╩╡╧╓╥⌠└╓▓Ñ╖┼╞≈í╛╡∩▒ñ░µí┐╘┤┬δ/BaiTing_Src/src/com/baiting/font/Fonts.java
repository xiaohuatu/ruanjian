package com.baiting.font;

import java.awt.Font;

import com.baiting.Music;


public class Fonts extends Music {
	/*
	private static Font font;
	
	public void init() {
		InputStream inputSteam = null;
		try {
			File file = new File(getFontPath());
			inputSteam = new FileInputStream(file);
			if(null == font) {
			   font = Font.createFont(Font.TRUETYPE_FONT, inputSteam);
			}
			
		} catch (FontFormatException e) {
			log.info("异常......");
			e.printStackTrace();
		} catch (IOException e) {
			log.info("异常2......");
			e.printStackTrace();
		} finally {
			try {
				inputSteam.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}*/
	
	public static Font tabSongTi() {
		//return font.deriveFont(Font.PLAIN, 18f);
		return new Font(null, Font.PLAIN, 18);
	}
	
	public static Font songTi24() {
		//return font.deriveFont(Font.PLAIN, 24f);
		return new Font(null, Font.PLAIN, 24);
	}
	public static Font songTiB24() {
		//return font.deriveFont(Font.BOLD, 24);
		return new Font(null, Font.BOLD, 24);
	}
	
	public static Font songTi22() {
		//return font.deriveFont(Font.PLAIN, 22);
		return new Font(null, Font.PLAIN, 22);
	}
	public static Font songTiB22() {
		//return font.deriveFont(Font.BOLD, 22);
		return new Font(null, Font.BOLD, 22);
	}
	
	public static Font songTi20() {
		//return font.deriveFont(Font.PLAIN, 20);
		return new Font(null, Font.PLAIN, 20);
	}
	public static Font songTiB20() {
		//return font.deriveFont(Font.BOLD, 20);
		return new Font(null, Font.BOLD, 20);
	}
	
	public static Font songTi19() {
		//return font.deriveFont(Font.PLAIN, 19);
		return new Font(null, Font.PLAIN, 19);
	}
	public static Font songTiB19() {
		//return font.deriveFont(Font.BOLD, 19);
		return new Font(null, Font.BOLD, 19);
	}
	
	public static Font songTi18() {
		//return font.deriveFont(Font.PLAIN, 18);
		return new Font(null, Font.PLAIN, 18);
	}
	public static Font songTiB18() {
		//return font.deriveFont(Font.BOLD, 18);
		return new Font(null, Font.BOLD, 18);
	}
	
	public static Font songTi17() {
		//return font.deriveFont(Font.PLAIN, 17);
		return new Font(null, Font.PLAIN, 17);
	}
	
	public static Font songTiB17() {
		//return font.deriveFont(Font.BOLD, 17);
		return new Font(null, Font.BOLD, 17);
	}
	
	public static Font songTi16() {
		//return font.deriveFont(Font.PLAIN, 16);
		return new Font(null, Font.PLAIN, 16);
	}
	
	public static Font songTiB16() {
		//return font.deriveFont(Font.BOLD, 16);
		return new Font(null, Font.BOLD, 16);
	}
	
	public static Font songTiB15() {
		//return font.deriveFont(Font.BOLD, 15);
		return new Font(null, Font.BOLD, 15);
	}
	
	public static Font songTi15() {
		//return font.deriveFont(Font.PLAIN, 15);
		return new Font(null, Font.PLAIN, 15);
	}
	
	public static Font songTiB14() {
		//return font.deriveFont(Font.BOLD, 14);
		return new Font(null, Font.BOLD, 14);
	}
	
	public static Font songTi14() {
		//return font.deriveFont(Font.PLAIN, 14);
		return new Font(null, Font.PLAIN, 14);
	}
	
	public static Font songTiB13() {
		//return font.deriveFont(Font.BOLD, 13);
		return new Font(null, Font.BOLD, 13);
	}
	
	public static Font songTi13() {
		//return font.deriveFont(Font.PLAIN, 13);
		return new Font(null, Font.PLAIN, 13);
	}
	
	public static Font songTiB12() {
		//return font.deriveFont(Font.BOLD, 12);
		return new Font(null, Font.BOLD, 12);
	}
	
	public static Font songTi12() {
		//return font.deriveFont(Font.PLAIN, 12);
		return new Font(null, Font.PLAIN, 12);
	}
	
	public static Font songTiB11() {
		//return font.deriveFont(Font.BOLD, 11);
		return new Font(null, Font.BOLD, 11);
	}
	
	public static Font songTi11() {
		//return font.deriveFont(Font.PLAIN, 11);
		return new Font(null, Font.PLAIN, 11);
	}
	
	public static Font songTiB10() {
		//return font.deriveFont(Font.BOLD, 10);
		return new Font(null, Font.BOLD, 10);
	}
	
	public static Font songTi10() {
		//return font.deriveFont(Font.PLAIN, 10);
		return new Font(null, Font.PLAIN, 10);
	}
	
	public static Font songTiB9() {
		//return font.deriveFont(Font.BOLD, 9);
		return new Font(null, Font.BOLD, 9);
	}
	
	public static Font songTi9() {
		//return font.deriveFont(Font.PLAIN, 9);
		return new Font(null, Font.PLAIN, 9);
	}
	
	public static Font songTiB8() {
		//return font.deriveFont(Font.BOLD, 8);
		return new Font(null, Font.BOLD, 8);
	}
	
	public static Font songTi8() {
		//return font.deriveFont(Font.PLAIN, 8);
		return new Font(null, Font.PLAIN, 8);
	}
	

}
