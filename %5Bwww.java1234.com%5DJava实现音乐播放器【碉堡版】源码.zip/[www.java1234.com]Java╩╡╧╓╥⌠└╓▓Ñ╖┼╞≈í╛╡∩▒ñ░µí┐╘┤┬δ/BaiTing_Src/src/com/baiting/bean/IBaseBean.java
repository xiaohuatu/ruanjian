package com.baiting.bean;

import java.io.Serializable;

public interface IBaseBean extends Serializable {

}
